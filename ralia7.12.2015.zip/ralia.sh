/home/rebooted/Scripts/ralia/ralia.pyc
