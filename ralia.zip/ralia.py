db_location = "/home/rebooted/Scripts/ralia/db.txt"
username = "user"
host = "ralia"
prompt = " >>> "

import subprocess

# importing subprocess module so that this Python script can invoke outside programs and scripts.

try:
	db = open(db_location)
except:
	print("The standard database file appears not to exist.\nIf it does, please edit this file and\nchange the 'db' variable to the location of\nthe database file.")
	exit()

# looking for a database file, and giving an error if the file isn't found.

count = 0
for line in db:
	count = count + 1
db.close()
db = open(db_location)

while True:
	executed_count = 0
	input = raw_input(username + "@" + host + prompt)
	if input == "exit":
		exit()
	else:
		input = input + " -> "
		for line in db:
			executed_count = executed_count + 1
			if line.startswith(input):
				execute_platform = line.split(input,1)
				execute = execute_platform[1]
				execute = execute.rstrip()
				subprocess.call(execute, shell=True)
				exit()
			else:
				continue
