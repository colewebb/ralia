Welcome to Ralia!

In order to set up this program, do the following:

 0. Install Python version 2.7 on your computer.
 1. Unpack the zip file into some otherwise empty directory on your computer. This location MUST be in the executable path.
 2. Edit the file ralia.py. The first few lines are variable assignments. Please edit these variable assignments. The only important one is the first one, db_location. Please enter the complete path of the database file db.txt. (Note: it must be a complete path. /home/user/stuff/ works, but ~/stuff/ doesn't. I'm working on it.)
 3. Tweak your database to whatever you want it to look like. Put the key value first, then " -> ", then the command you want to run. You have to a space on both sides of the arrow.
 4. Enjoy!
