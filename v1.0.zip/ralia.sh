python /home/rebooted/Scripts/ralia/ralia.py

