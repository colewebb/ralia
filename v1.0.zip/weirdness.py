import subprocess
while True:
	input = raw_input("$")
	subprocess.call(input, shell=True)
